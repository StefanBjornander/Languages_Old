package main

import "fmt"
import "poker"

func main() {
  var hand poker.Hand = poker.NewHand("TS KH 2C 4D AC")
  fmt.Println(hand)
}