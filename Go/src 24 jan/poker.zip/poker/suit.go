package poker

type Suit int

const (
  Clubs Suit = iota
  Diamonds
  Hearts
  Spades
)