package poker

import "fmt"
import "strings"

type ComparableHand interface {
  CompareWith(compareTo ComparableHand) (result int)
}

type Hand struct {
  m_cards [5] Card
  m_maxValue, m_minValue int
  m_map map[int]int
}

func (hand Hand) CompareWith(compareTo ComparableHand) (result int) {
  result = 0
  return 0
}

func NewHand(text string) Hand {
  var hand Hand
  var cardTextArray = strings.Split(text, " ")

  if len(cardTextArray) != 5 {
    fmt.Printf("Invalid number of cards in the hand: %d.\n", len(cardTextArray))
  }

  var index int = 0
  for _, cardText := range cardTextArray {
    if len(cardText) != 2 {
      fmt.Printf("Invalid length of card text: %s.\n", cardText)
    }

    var valueChar = string(cardText[0])
    var valueCharUpper = strings.ToUpper(valueChar)

    const valueText string = "23456789TJQKA"
    var value int

    if strings.Contains(valueText, valueCharUpper) {
      value = strings.Index(valueText, valueCharUpper) + 2
    } else {
      fmt.Printf("Invalid card value: %s.\n", valueChar)
    }

    var suitChar = string(cardText[1])
    var suitCharUpper = strings.ToUpper(suitChar)

    var suitMap = map[string]Suit {"S": Spades, "H": Hearts, "D": Diamonds, "C": Clubs}
    var suit, exists = suitMap[suitCharUpper]
    
    if !exists {
      fmt.Printf("Invalid card suit: %s.\n", suitChar)
    }

    var card Card = NewCard(value, suit)
    hand.m_cards[index] = card
    index++
    
    /*if contains(hand.m_cards, card) {
      fmt.Println("Double card:", card)
    }*/
  }

  return hand
}

func (hand Hand) String() string {
  var buffer string = "{"
  var first bool = true

  for _, card := range hand.m_cards {
    if !first {
      buffer += ", "
    }

    buffer += card.String()
    first = false
  }

  buffer += "}"

  if hand.m_maxValue != 0 {
    buffer += ", max value " + string(hand.m_maxValue)
  }

  if hand.m_minValue != 0 {
    buffer += ", min value " + string(hand.m_minValue)
  }

  /*buffer += ", ["
  var firstList bool = true

  for size, list := range hand.m_map {
    if !firstList {
      buffer += ", "
    }

    buffer += string(size) + ": ["
    var firstValue bool = true

    for value := range list {
      if !firstValue {
        buffer += ", "
      }

      buffer += string(value)
      firstValue = false
    }

    firstList = false
    buffer.Append("]")
  }*/

  return buffer
}

