package poker

type Rank int

const (
  Nothing Value = iota
  OnePair
  TwoPairs
  ThreeOfAKind
  Straight
  Flush
  FullHouse
  FourOfAKind
  StraightFlush
  RoyalFlush
)