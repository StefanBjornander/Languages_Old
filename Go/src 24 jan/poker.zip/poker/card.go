package poker

type Card struct {
  m_value int
  m_suit Suit
}

func NewCard(value int, suit Suit) Card {
  return Card{value, suit}
}

func (card Card) Value() int {
  return card.m_value
}

func (card Card) Suit() Suit {
  return card.m_suit
}

func (card Card) String() string {
  var valueArray = [15]string{"", "", "Two", "Three", "Four", "Five", "Six", "Seven",
                              "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"}
  var suitArray = [4]string{"Clubs", "Diamonds", "Hearts", "Spades"}
  return valueArray[card.m_value] + " of " + suitArray[card.m_suit]
}

/*
func (card Card*) Equals(object obj) bool {
  if (obj is Card) {
    card Card*ard = (Card) obj
    return (m_value == card.m_value) &&
           (m_suit == card.m_suit)
  }

  return false
}

public class HighestFirst : IComparer<Card> {
  public int Compare(Card leftCard, Card rightCard) {
    return rightCard.Value - leftCard.Value
  }
}*/
