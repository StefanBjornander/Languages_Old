package rank

const (
  Nothing int = iota
  OnePair
  TwoPairs
  ThreeOfAKind
  Straight
  Flush
  FullHouse
  FourOfAKind
  StraightFlush
  RoyalFlush
)