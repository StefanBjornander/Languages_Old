package result

const (
  Tie int = iota
  Win
  Lose
)