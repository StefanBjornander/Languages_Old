﻿package poker

import "container/list"

type set struct {
  size int
  list list
}
